import datetime as dt
import os
import zipfile
from step_motor_manager import StepMotorManager
from threading import Thread

#import pandas as pd
from flask import Flask, request, send_file
from flask import jsonify
from flask_cors import CORS
from scipy.io.wavfile import read

app = Flask(__name__)
CORS(app)

UPLOAD_FOLDER = "/uploads"
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), "uploads")

SOUNDS_FOLDER = os.path.join(os.path.dirname(__file__), "static", "sounds")
LOGS_FILE_DIR = os.path.join(os.path.dirname(__file__), "logs/parrot-screaming-data.csv")

file_names = []
manager = StepMotorManager()

for root, dirs, files in os.walk(SOUNDS_FOLDER):
    for file in files:
        file_names.append(file)

def is_parrot_screaming0(audio, sample_rate):
    min_peak_val = 12000
    focus_size = int(0.23 * sample_rate)
    #print(type(audio))
   # print('audio size', audio.shape)
    i = 0
    peaks = []
    curr_max_peak = -99999999999
    data = audio.tolist()
    for val in data:
        if val >= min_peak_val:
            curr_max_peak = val
        if i % focus_size == 0:
           # print(i)
            if curr_max_peak >= min_peak_val:  # new peak found
                peaks.append(curr_max_peak)
                if len(peaks) >= 4:
                    return True
                curr_max_peak = -99999999999
            else:
                peaks = []
        i += 1
    return len(peaks) >= 4


@app.route("/")
def index():
    return app.send_static_file("index.html")


@app.route("/sounds/<sound_name>", methods=["GET"])
def get_sound(sound_name):
    return send_file("static/sounds/" + sound_name)


@app.route("/upload_file", methods=['POST'])
def upload_file():
    file = request.files['audio_data']
    print('request recieved')
    file.save(os.path.join(app.config['UPLOAD_FOLDER'], "audio.wav"))

    sample_rate, audio = read(app.config['UPLOAD_FOLDER'] + "/audio.wav")
    if audio.ndim == 2:
        audio = audio[:, 0]

    result = is_parrot_screaming(audio, sample_rate)
    print('result! ')
    if result:
       # pid = os.fork()
       # if pid == 0: # new process
           # os.system("python3 step_motor_manager.py")
           # exit()
       # thread = Thread(target= manager.onParrotScream)
       # thread.start()
       return  manager.onParrotScream()
     #   with open(LOGS_FILE_DIR, mode='a') as log_file:
    #        date_time_data = [dt.datetime.now().isoformat(' ', 'seconds')]
    #        scream_date_time = pd.DataFrame(date_time_data, columns=["date_time"])
    #        scream_date_time.to_csv(log_file, header=False, index=False, columns=["date_time"])
	
    print("Is parrot screaming: ", result)
    return jsonify(is_parrot_screaming=result)


@app.route("/soundNames", methods=["GET"])
def get_all_sounds():
    return jsonify(file_names)



def is_parrot_screaming(audio, sample_rate):
    if audio.shape[0] == 0:
        return
    min_peak_val = 12000
    focus_size = int(0.23 * sample_rate)
    #print(type(audio))
    #print("audio size:", audio.shape)
    #print("max: ", audio.max())
    #print("mean: ", audio.mean())
    # FIND ALL RANGES
    ranges = {}
    ranges[0] = focus_size
    last_end_range = focus_size
    while True:
        range_start = last_end_range
        range_end = last_end_range + focus_size
        last_end_range = range_end
        
        ranges[range_start] = range_end
        if range_end >= audio.shape[0]: # out of bounds of the array
            range_end = audio.shape[0]
            ranges[range_start] = range_end
            break
#     print(ranges)
    
    # SPLIT TO N ARRAYS
    audio_chunks = []
    for start, end in ranges.items():
        audio_chunks.append(audio[start: end])
    
    print('focus size', focus_size)
    screaming_sequence = []
    for np_arr in audio_chunks:
        if np_arr.max() >= min_peak_val:
            screaming_sequence.append(True)
        else:
            screaming_sequence.append(False)
    
    seq_scream_counter = 0
    for is_screaming in screaming_sequence:
        if is_screaming:
            seq_scream_counter+=1
            if seq_scream_counter >=3:
                return True
        else:
            seq_scream_counter = 0
    
    return seq_scream_counter >=3



if __name__ == '__main__':
    app.debug = True
    app.run(host='0.0.0.0', port=5005)

