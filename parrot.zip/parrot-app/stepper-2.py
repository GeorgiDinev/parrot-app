import time
import time
import RPi.GPIO as GPIO
import sys
# We determine how we will call our pins,
# in this version we do it via GPIO numbers
#GPIO.cleanup()
GPIO.setmode(GPIO.BCM)

# Here we define further output pins for IN1, IN2, IN3, IN4 controller inputs
pins = [27,22,23,24]

# We note that pins are output and give them a starting position of false or 0
for pin in pins:
    GPIO.setup(pin,GPIO.OUT)
    GPIO.output(pin,False)
# We define next electromagnet activation sequences for half-step control
sequence = [ [1,0,0,0],
		[1,1,0,0],
		[0,1,0,0],
		[0,1,1,0],
		[0,0,1,0],
		[0,0,1,1],
		[0,0,0,1],
		[1,0,0,1] ]

clockwise_dir = True
if len(sys.argv) >1:
   clockwise_dir = sys.argv[1] == 'down'


half_steps_range = []
pins_range = []
if clockwise_dir:
    half_steps_range = range(8)
    pins_range = range(4)
else:
    half_steps_range = range(7, -1, -1)
    pins_range = range(3, -1, -1)

#print('pins: ', pins_range)
#print('half_ steps', half_steps_range)

start_time = time.time()
print(start_time)
while True:
    stop_motor =False
    for half_step in half_steps_range:
        for pin in pins_range:
            GPIO.output(pins[pin], sequence[half_step][pin])
        curr_time = time.time()
        if (curr_time - start_time) > 19.5:
            stop_motor = True
            break
        time.sleep(0.0007)
    if stop_motor:
       break
GPIO.cleanup()
