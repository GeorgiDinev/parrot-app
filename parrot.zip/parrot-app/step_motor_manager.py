
from step_motor import StepMotor
from threading import Thread
import time
from subprocess import call
import motor_controller

class StepMotorManager:
    def __init__(self):
       # self.step_motor =  StepMotor([27,22,23,24], 19.5)
       # self.wait_secs_until_pull_curtain= (2 * 60) + 19.5
        self.reset_remaining_time = True

    def onParrotScream(self):
        logg = 'izvika onParrotScream, '
        # reset time remaining before curtain pulling
        # StepMotorManager.HAS_PARROT_SCREAMED = True
        # check if the motor is idle and the curtain is up -> move the curtain down
        if 1 == 1:
            with open('/home/pi/parrot-app/curtain_state.txt', 'r+') as curtain_file:
                curtain_data = curtain_file.read().splitlines()
                moving_state = curtain_data[0]
                logg += 'vleze v with, '
                if moving_state.strip().lower() == 'moving': return
                if(curtain_data[1].strip().lower() == 'up'):
                    #push_curtain_thread = Thread(target=self.__push_curtain_down, args=(self.step_motor,))
                    #self.step_motor.move_clockwise() # move down
                    #push_curtain_thread.start()
                    #self. __push_curtain_down(self.step_motor)
                    #call(['python3', 'motor-controller.py &'])
                    #logg+= 'startira scripta.'
                    #curtain_file.seek(0)
                    #curtain_file.write("down")
                    #curtain_file.truncate()
                    # start the waiting threa
                    #call(['python3', 'motor-.py'])
                    thread = Thread(target= motor_controller.start)
                    thread.start()

                   #pull_curtain_thread.start() self.__pull_curtain_up
                    #self.__pull_curtain_up(self.step_motor,self.wait_secs_until_pull_curtain)
                          
        # else skip moving the stepper for now
        return logg
    def __pull_curtain_up(self, step_motor, wait_seconds_before_pull):
        start_time = time.time()
        # wait x seconds before pulling the  curtain up
        while (time.time() - start_time) < wait_seconds_before_pull:# todo:check the q remaining
            time.sleep(1)

        # time has passed, its time to poll
        with open("curtain_state.txt", 'r+') as curtain_file:
            curtain_state = curtain_file.read()
            if(curtain_state.strip().lower() == 'down'):
                step_motor.move_reverse_clockwise()# move up
                curtain_file.seek(0)
                curtain_file.write("up")
                curtain_file.truncate()

    def __push_curtain_down(self, step_motor):
        print("MOVING DOWN STARTED!!!")
        step_motor.setup_pins()
        step_motor.move_clockwise() # move down
        print('MOVING DOWN FINISHED!!!')
#manager = StepMotorManager()
#manager.onParrotScream()
